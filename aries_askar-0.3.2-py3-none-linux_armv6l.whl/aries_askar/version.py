"""aries_askar library wrapper version."""

__version__ = "0.3.2"
